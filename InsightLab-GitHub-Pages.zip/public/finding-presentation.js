// Keep unanswered questions and user constraints in the audit trail rather
// than presenting them as discoveries. This does not modify saved reports.
export function presentableFinding(item) {
  if (!item || (item.kind || item.status) === '证据不足') return false;
  const q=String(item.question||'').trim();
  return !/^(?:没有|缺乏|无|不|不得|不能|无需|避免|禁止|仅|只)(?:.{0,32})(?:不编造|不虚构|不猜|不推测|不得|不要|不能|不将|不使用|无需|保留|区分|标注|验证|信息|规格|线径|供应商|型号)/u.test(q);
}
