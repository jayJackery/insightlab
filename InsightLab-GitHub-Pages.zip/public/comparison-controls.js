// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=0800a8a9d402c637';
