// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=2e73a644157d89de';
