// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=e689adf3485a35eb';
