// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=f2e498c105ae0577';
