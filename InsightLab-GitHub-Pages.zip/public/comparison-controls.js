// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=e1b1b7c52b73e0ae';
