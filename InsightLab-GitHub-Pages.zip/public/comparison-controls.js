// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=68dd7a5dc788ea7c';
