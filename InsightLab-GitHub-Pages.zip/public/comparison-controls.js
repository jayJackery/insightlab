// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=0bbdbb7c8afe1b7e';
