// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=5fdc64dfb887c21e';
