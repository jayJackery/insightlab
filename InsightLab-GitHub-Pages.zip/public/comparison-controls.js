// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=308a2dc1dbe5e95a';
