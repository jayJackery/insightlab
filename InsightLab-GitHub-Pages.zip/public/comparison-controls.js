// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=1e906dde452c5095';
