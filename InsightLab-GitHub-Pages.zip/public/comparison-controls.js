// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=f8df79f0af3b4f0a';
