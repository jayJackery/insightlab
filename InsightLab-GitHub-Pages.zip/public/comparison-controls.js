// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=17e30a02db75bbc3';
