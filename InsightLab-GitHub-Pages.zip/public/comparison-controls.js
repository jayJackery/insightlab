// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=673b8c9b2b4ed07a';
