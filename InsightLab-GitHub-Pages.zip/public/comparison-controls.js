// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=4849afa09f45cf76';
