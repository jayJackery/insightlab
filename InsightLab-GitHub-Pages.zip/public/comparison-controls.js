// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=161712dcf80d38a1';
