// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=7ba885dfbcdd9182';
