// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=c96d44618f0b3787';
