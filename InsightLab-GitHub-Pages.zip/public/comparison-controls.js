// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=80e2ed523514c486';
