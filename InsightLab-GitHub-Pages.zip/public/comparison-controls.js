// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=b03acb76e2c8601f';
