// Stable entry point; one implementation lives in competitor-controls.js.
export * from './competitor-controls.js?v=12ab2a8b984516c3';
