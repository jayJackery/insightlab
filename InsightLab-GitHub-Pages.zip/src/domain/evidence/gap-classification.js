// Evidence not used in prose remains in the audit trail. A lexical match is a
// conservative warning, not proof of semantic support; independent review is
// still required for every report before publication.
export function classifyEvidenceGaps(gaps,report){
  const text=JSON.stringify({summary:report?.executiveSummary,answers:report?.userQuestionAnswers,questions:report?.questionAnswers,routes:report?.technologyDeepDives,recommendations:report?.recommendations}).normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
  return (gaps||[]).map(gap=>{
    const claim=String(gap.text||'').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
    const used=claim.length>=12&&text.includes(claim);
    const conflict=gap.kind==='condition_conflict'||/冲突|错配|不同|conflict|mismatch/i.test(gap.reason||'');
    const category=used?'影响关键结论':conflict?'资料冲突':gap.kind==='fact_verification'?'未采用的存疑事实':'需标明条件的证据缺口';
    return {...gap,category,usedInReport:used};
  });
}
