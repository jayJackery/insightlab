import pako from '../../../vendor/pako.js?v=eb89bbea8d70eb5c';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
