import pako from '../../../vendor/pako.js?v=17e30a02db75bbc3';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
