import pako from '../../../vendor/pako.js?v=f2e498c105ae0577';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
