import pako from '../../../vendor/pako.js?v=344e237554f660f3';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
