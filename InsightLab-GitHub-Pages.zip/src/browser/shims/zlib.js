import pako from '../../../vendor/pako.js?v=b03acb76e2c8601f';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
