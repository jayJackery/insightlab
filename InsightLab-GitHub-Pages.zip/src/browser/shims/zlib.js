import pako from '../../../vendor/pako.js?v=963bf97acdd56880';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
