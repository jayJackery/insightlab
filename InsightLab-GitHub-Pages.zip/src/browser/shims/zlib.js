import pako from '../../../vendor/pako.js?v=c96d44618f0b3787';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
