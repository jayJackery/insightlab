import pako from '../../../vendor/pako.js?v=f8df79f0af3b4f0a';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
