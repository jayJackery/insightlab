import pako from '../../../vendor/pako.js?v=673b8c9b2b4ed07a';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
