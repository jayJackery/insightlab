import pako from '../../../vendor/pako.js?v=0800a8a9d402c637';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
