import pako from '../../../vendor/pako.js?v=68dd7a5dc788ea7c';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
