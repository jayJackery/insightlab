import pako from '../../../vendor/pako.js?v=1e906dde452c5095';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
