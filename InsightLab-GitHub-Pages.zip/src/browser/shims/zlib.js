import pako from '../../../vendor/pako.js?v=7ba885dfbcdd9182';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
