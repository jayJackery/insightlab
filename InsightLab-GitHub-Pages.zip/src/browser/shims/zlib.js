import pako from '../../../vendor/pako.js?v=3335b35ed4103b16';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
