import pako from '../../../vendor/pako.js?v=4849afa09f45cf76';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
