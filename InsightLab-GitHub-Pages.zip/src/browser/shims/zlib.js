import pako from '../../../vendor/pako.js?v=308a2dc1dbe5e95a';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
