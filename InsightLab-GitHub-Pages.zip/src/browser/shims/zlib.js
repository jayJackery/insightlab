import pako from '../../../vendor/pako.js?v=edeabeb7bee1a997';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
