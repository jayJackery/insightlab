import pako from '../../../vendor/pako.js?v=12ab2a8b984516c3';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
