import pako from '../../../vendor/pako.js?v=80e2ed523514c486';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
