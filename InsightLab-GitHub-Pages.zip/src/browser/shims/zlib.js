import pako from '../../../vendor/pako.js?v=2e73a644157d89de';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
