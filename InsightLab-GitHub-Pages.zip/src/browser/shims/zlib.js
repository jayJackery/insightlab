import pako from '../../../vendor/pako.js?v=5fdc64dfb887c21e';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
