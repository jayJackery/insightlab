import pako from '../../../vendor/pako.js?v=161712dcf80d38a1';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
