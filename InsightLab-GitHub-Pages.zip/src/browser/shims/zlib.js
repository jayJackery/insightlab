import pako from '../../../vendor/pako.js?v=64648cbe7983be34';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
