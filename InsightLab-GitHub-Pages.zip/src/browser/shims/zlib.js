import pako from '../../../vendor/pako.js?v=5ce36264f5ca040e';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
