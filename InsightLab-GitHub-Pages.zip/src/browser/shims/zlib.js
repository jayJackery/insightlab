import pako from '../../../vendor/pako.js?v=0bbdbb7c8afe1b7e';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
