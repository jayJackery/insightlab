import pako from '../../../vendor/pako.js?v=e689adf3485a35eb';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
