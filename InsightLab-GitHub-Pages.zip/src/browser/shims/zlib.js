import pako from '../../../vendor/pako.js?v=e1b1b7c52b73e0ae';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
