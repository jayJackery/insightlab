import pako from '../../../vendor/pako.js?v=ee7558e3cfde90fc';
export const deflateRawSync=bytes=>pako.deflateRaw(bytes);
