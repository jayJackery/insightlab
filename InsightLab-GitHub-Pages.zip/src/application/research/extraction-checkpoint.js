import {createHash} from '../../browser/shims/crypto.js?v=64648cbe7983be34';
import {sourceContext} from '../../domain/evidence/report-content.js?v=64648cbe7983be34';

// The signature follows model-visible inputs, not storage/build metadata.
export function extractionInputSignature({inputText,plan,criteria,definitions,products,batch}) {
  const value=['evidence-extraction-v1',inputText,plan,criteria,definitions,products,sourceContext(batch,plan,batch.length===1?12000:16000)];
  return createHash('sha256').update(JSON.stringify(value)).digest('hex');
}
