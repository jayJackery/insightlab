import {createHash} from '../../browser/shims/crypto.js?v=17e30a02db75bbc3';
import {sourceContext} from '../../domain/evidence/report-content.js?v=17e30a02db75bbc3';

// The signature follows model-visible inputs, not storage/build metadata.
export function extractionInputSignature({inputText,plan,criteria,definitions,products,batch}) {
  const value=['evidence-extraction-v1',inputText,plan,criteria,definitions,products,sourceContext(batch,plan,batch.length===1?12000:16000)];
  return createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

export function savedSearchDecision({research={},signature,workflowVersion,sameScope,evidence={}}) {
  if(!research.sources?.length||!['passed','limited'].includes(research.searchQuality?.status))return 'search';
  if(research.runtime?.workflowVersion===workflowVersion&&research.contractSignature===signature)return 'resume';
  if(research.runtime?.workflowVersion==='rd-research/18'&&sameScope&&evidence.audit?.status==='passed')return 'resume';
  const version=Number(/^rd-research\/(\d+)$/.exec(research.runtime?.workflowVersion||'')?.[1]);
  return sameScope&&version>=6&&version<=19?'revalidate':'search';
}

// "needs_review" can be a complete set of fact decisions; reuse those
// decisions without treating uncertain facts as supported or publishable.
export function reusableAuditedEvidence(evidence={}) {
  const audit=evidence.audit;
  return audit?.version==='independent-fact-v7'&&['passed','needs_review'].includes(audit.status)&&Array.isArray(audit.checks)&&audit.checks.length>0&&audit.checks.every(check=>['supported','needs_review'].includes(check.status));
}
