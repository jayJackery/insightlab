export async function extractWithSplitRecovery({batch,extract,save,combine,onSplit=()=>{},depth=0,maxDepth=4,singleRetry=1,onRetry=()=>{}}) {
  let value;
  try {
    value=await extract(batch,{depth});
  } catch(error) {
    const recoverable=['MODEL_TRUNCATED','MODEL_TIMEOUT','MODEL_NETWORK','MODEL_STREAM_INCOMPLETE'].includes(error?.code);
    if(!recoverable)throw error;
    if(batch.length<2){
      if(singleRetry>0&&['MODEL_TIMEOUT','MODEL_NETWORK','MODEL_STREAM_INCOMPLETE'].includes(error.code)){
        onRetry({depth,sourceCount:1,code:error.code});
        return extractWithSplitRecovery({batch,extract,save,combine,onSplit,depth,maxDepth,singleRetry:singleRetry-1,onRetry});
      }
      throw error;
    }
    if(depth>=maxDepth)throw error;
    const midpoint=Math.ceil(batch.length/2),parts=[batch.slice(0,midpoint),batch.slice(midpoint)];
    onSplit({depth,code:error.code,sourceCount:batch.length,partSizes:parts.map(part=>part.length)});
    const values=[];
    for(const part of parts) values.push(await extractWithSplitRecovery({batch:part,extract,save,combine,onSplit,depth:depth+1,maxDepth,singleRetry,onRetry}));
    return combine(values);
  }
  await save(batch,value);
  return value;
}
