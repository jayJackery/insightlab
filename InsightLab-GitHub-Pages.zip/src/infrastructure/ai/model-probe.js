export const PLAN_ARRAYS=['questions','queries','criteria','competitors','assumptions','sourceStrategy'];
export function validatePlanShape(value){
  for(const name of PLAN_ARRAYS)if(!Array.isArray(value[name])||value[name].some(item=>typeof item!=='string'||!item.trim()))throw Error('计划字段'+name+'必须是字符串数组。');
  if(!value.questions.length||!value.queries.length)throw Error('研究计划缺少问题或有效查询。');
}
const COVERAGE_ARRAYS=['questions','technicalGaps','missingSpecifications','followupQueries'];
export function validateCoverageShape(value){
  if(!Array.isArray(value.questions)||!value.questions.length)throw Error('覆盖审查缺少questions数组。');
  for(const question of value.questions){
    if(!question||typeof question!=='object'||!['answered','partial','missing'].includes(question.status)||typeof question.questionId!=='string'||typeof question.missing!=='string')throw Error('覆盖审查questions字段结构无效。');
  }
  if(!value.technical||typeof value.technical!=='object'||['principle','implementation','tradeoffs','validation'].some(key=>typeof value.technical[key]!=='boolean'))throw Error('覆盖审查technical字段结构无效。');
  if(!Array.isArray(value.technicalGaps)||!Array.isArray(value.missingSpecifications)||!Array.isArray(value.followupQueries))throw Error('覆盖审查缺少必需数组。');
  for(const item of value.missingSpecifications)if(!item||typeof item.product!=='string'||!Array.isArray(item.metrics)||item.metrics.some(metric=>typeof metric!=='string'))throw Error('覆盖审查missingSpecifications字段结构无效。');
  if(value.followupQueries.some(query=>typeof query!=='string'))throw Error('覆盖审查followupQueries必须是字符串数组。');
}
// Same transport, output parser and plan shape as production; no credential/response logging.
export async function checkModelCompatibility(model,modelName){
  await model([
    {role:'system',content:'这是研究应用的JSON兼容检测。只返回一个完整JSON对象，不输出推理或Markdown。字段questions、queries、criteria、competitors、assumptions、sourceStrategy均为字符串数组，questions和queries至少一项。'},
    {role:'user',content:'为一个公开示例问题制定极小计划：查找Example 1000的标称容量。只需一条问题、一条查询、一个指标；其他数组可以为空。不得编造产品容量或结论。'},
  ],{stage:'模型结构化兼容检测',arrays:PLAN_ARRAYS,validate:validatePlanShape,maxTokens:4096,maxAttempts:1,reasoning:'low'});
  return '结构化兼容检测通过 · '+modelName+'；已取得非空JSON和有效计划字段。小样本通过不保证长研究每次成功。';
}
// Catch endpoints that accept plan JSON but fail on the structured coverage-review shape,
// before the workflow spends time and search budget collecting sources.
export async function checkCoverageCompatibility(model){
  await model([
    {role:'system',content:'这是研发研究证据覆盖审查兼容性预检。只返回一个完整JSON对象，不输出推理或Markdown。必需字段：questions（含questionId,status,missing），technical（principle,implementation,tradeoffs,validation四个布尔值），technicalGaps字符串数组，missingSpecifications（含product与metrics字符串数组），followupQueries字符串数组。'},
    {role:'user',content:'仅对以下虚构样例检查结构是否可返回，不判断真实产品：研究问题Q1“样例设备如何散热”；当前资料是“产品页宣传静音”，缺少风道/验证证据。请按字段给出partial、一个技术缺口和一条补查方向。'},
  ],{stage:'检索前覆盖审查兼容性预检',arrays:COVERAGE_ARRAYS,validate:validateCoverageShape,maxTokens:2048,maxAttempts:1,reasoning:'low'});
  return true;
}
